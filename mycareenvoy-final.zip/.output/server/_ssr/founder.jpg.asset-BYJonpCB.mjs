//#region node_modules/.nitro/vite/services/ssr/assets/founder.jpg.asset-BYJonpCB.js
var founder_jpg_asset_default = {
	version: 1,
	asset_id: "dc0e041e-6235-447a-92a7-702718c9b56b",
	project_id: "1d9c731d-19f3-49c0-8626-360ca834fbbf",
	url: "/__l5e/assets-v1/dc0e041e-6235-447a-92a7-702718c9b56b/founder.jpg",
	r2_key: "a/v1/1d9c731d-19f3-49c0-8626-360ca834fbbf/dc0e041e-6235-447a-92a7-702718c9b56b/founder.jpg",
	original_filename: "founder.jpg",
	size: 253388,
	content_type: "image/jpeg",
	created_at: "2026-10-14T01:47:58Z"
};
//#endregion
export { founder_jpg_asset_default as t };
