export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      care_requests: {
        Row: {
          consent: boolean
          country: string | null
          created_at: string
          email: string
          existing_family: string | null
          full_name: string
          id: string
          message: string | null
          notes: string | null
          parent_location: string | null
          parent_name: string | null
          phone: string | null
          service_id: string
          status: string
          urgency: string | null
        }
        Insert: {
          consent?: boolean
          country?: string | null
          created_at?: string
          email: string
          existing_family?: string | null
          full_name: string
          id?: string
          message?: string | null
          notes?: string | null
          parent_location?: string | null
          parent_name?: string | null
          phone?: string | null
          service_id: string
          status?: string
          urgency?: string | null
        }
        Update: {
          consent?: boolean
          country?: string | null
          created_at?: string
          email?: string
          existing_family?: string | null
          full_name?: string
          id?: string
          message?: string | null
          notes?: string | null
          parent_location?: string | null
          parent_name?: string | null
          phone?: string | null
          service_id?: string
          status?: string
          urgency?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "care_requests_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      caregiver_applicants: {
        Row: {
          created_at: string
          details: Json
          email: string | null
          files: Json
          full_name: string
          id: string
          license_number: string | null
          notes: string | null
          phone: string
          source: string | null
          status: string
          years_experience: string | null
        }
        Insert: {
          created_at?: string
          details?: Json
          email?: string | null
          files?: Json
          full_name: string
          id?: string
          license_number?: string | null
          notes?: string | null
          phone: string
          source?: string | null
          status?: string
          years_experience?: string | null
        }
        Update: {
          created_at?: string
          details?: Json
          email?: string | null
          files?: Json
          full_name?: string
          id?: string
          license_number?: string | null
          notes?: string | null
          phone?: string
          source?: string | null
          status?: string
          years_experience?: string | null
        }
        Relationships: []
      }
      doctor_applicants: {
        Row: {
          created_at: string
          details: Json
          email: string | null
          files: Json
          full_name: string
          id: string
          license_number: string | null
          notes: string | null
          phone: string
          source: string | null
          status: string
          years_experience: string | null
        }
        Insert: {
          created_at?: string
          details?: Json
          email?: string | null
          files?: Json
          full_name: string
          id?: string
          license_number?: string | null
          notes?: string | null
          phone: string
          source?: string | null
          status?: string
          years_experience?: string | null
        }
        Update: {
          created_at?: string
          details?: Json
          email?: string | null
          files?: Json
          full_name?: string
          id?: string
          license_number?: string | null
          notes?: string | null
          phone?: string
          source?: string | null
          status?: string
          years_experience?: string | null
        }
        Relationships: []
      }
      employer_inquiries: {
        Row: {
          company: string
          company_size: string | null
          created_at: string
          details: Json
          email: string
          full_name: string
          id: string
          notes: string | null
          phone: string | null
          status: string
        }
        Insert: {
          company: string
          company_size?: string | null
          created_at?: string
          details?: Json
          email: string
          full_name: string
          id?: string
          notes?: string | null
          phone?: string | null
          status?: string
        }
        Update: {
          company?: string
          company_size?: string | null
          created_at?: string
          details?: Json
          email?: string
          full_name?: string
          id?: string
          notes?: string | null
          phone?: string | null
          status?: string
        }
        Relationships: []
      }
      family_leads: {
        Row: {
          baseline_location: string | null
          baseline_total_usd: number | null
          caregiver_escort: boolean
          country: string | null
          created_at: string
          details: Json
          email: string
          family_time_zone: string | null
          full_name: string
          id: string
          join_video_call: boolean
          notes: string | null
          parent_age: number | null
          parent_area: string | null
          parent_consent: boolean
          parent_name: string | null
          phone: string | null
          plan: string | null
          relationship: string | null
          siblings_share: string | null
          source: string | null
          status: string
          timezone: string | null
        }
        Insert: {
          baseline_location?: string | null
          baseline_total_usd?: number | null
          caregiver_escort?: boolean
          country?: string | null
          created_at?: string
          details?: Json
          email: string
          family_time_zone?: string | null
          full_name: string
          id?: string
          join_video_call?: boolean
          notes?: string | null
          parent_age?: number | null
          parent_area?: string | null
          parent_consent?: boolean
          parent_name?: string | null
          phone?: string | null
          plan?: string | null
          relationship?: string | null
          siblings_share?: string | null
          source?: string | null
          status?: string
          timezone?: string | null
        }
        Update: {
          baseline_location?: string | null
          baseline_total_usd?: number | null
          caregiver_escort?: boolean
          country?: string | null
          created_at?: string
          details?: Json
          email?: string
          family_time_zone?: string | null
          full_name?: string
          id?: string
          join_video_call?: boolean
          notes?: string | null
          parent_age?: number | null
          parent_area?: string | null
          parent_consent?: boolean
          parent_name?: string | null
          phone?: string | null
          plan?: string | null
          relationship?: string | null
          siblings_share?: string | null
          source?: string | null
          status?: string
          timezone?: string | null
        }
        Relationships: []
      }
      lab_partner_applicants: {
        Row: {
          created_at: string
          details: Json
          email: string
          files: Json
          full_name: string
          id: string
          location: string
          notes: string | null
          phone: string
          registration_number: string | null
          status: string
          years_experience: string | null
        }
        Insert: {
          created_at?: string
          details?: Json
          email: string
          files?: Json
          full_name: string
          id?: string
          location: string
          notes?: string | null
          phone: string
          registration_number?: string | null
          status?: string
          years_experience?: string | null
        }
        Update: {
          created_at?: string
          details?: Json
          email?: string
          files?: Json
          full_name?: string
          id?: string
          location?: string
          notes?: string | null
          phone?: string
          registration_number?: string | null
          status?: string
          years_experience?: string | null
        }
        Relationships: []
      }
      leads: {
        Row: {
          country: string
          created_at: string
          email: string
          id: string
          name: string
          parent_city: string | null
          parent_location: string
          source: string
          whatsapp_number: string
        }
        Insert: {
          country: string
          created_at?: string
          email: string
          id?: string
          name: string
          parent_city?: string | null
          parent_location: string
          source?: string
          whatsapp_number: string
        }
        Update: {
          country?: string
          created_at?: string
          email?: string
          id?: string
          name?: string
          parent_city?: string | null
          parent_location?: string
          source?: string
          whatsapp_number?: string
        }
        Relationships: []
      }
      nurse_applicants: {
        Row: {
          created_at: string
          details: Json
          email: string | null
          files: Json
          full_name: string
          id: string
          license_number: string | null
          notes: string | null
          phone: string
          source: string | null
          status: string
          years_experience: string | null
        }
        Insert: {
          created_at?: string
          details?: Json
          email?: string | null
          files?: Json
          full_name: string
          id?: string
          license_number?: string | null
          notes?: string | null
          phone: string
          source?: string | null
          status?: string
          years_experience?: string | null
        }
        Update: {
          created_at?: string
          details?: Json
          email?: string | null
          files?: Json
          full_name?: string
          id?: string
          license_number?: string | null
          notes?: string | null
          phone?: string
          source?: string | null
          status?: string
          years_experience?: string | null
        }
        Relationships: []
      }
      partner_inquiries: {
        Row: {
          created_at: string
          details: Json
          email: string
          full_name: string
          id: string
          notes: string | null
          org_type: string | null
          organisation: string
          phone: string | null
          status: string
        }
        Insert: {
          created_at?: string
          details?: Json
          email: string
          full_name: string
          id?: string
          notes?: string | null
          org_type?: string | null
          organisation: string
          phone?: string | null
          status?: string
        }
        Update: {
          created_at?: string
          details?: Json
          email?: string
          full_name?: string
          id?: string
          notes?: string | null
          org_type?: string | null
          organisation?: string
          phone?: string | null
          status?: string
        }
        Relationships: []
      }
      pharmacy_partner_applicants: {
        Row: {
          created_at: string
          details: Json
          email: string
          files: Json
          full_name: string
          id: string
          location: string
          notes: string | null
          phone: string
          registration_number: string
          status: string
          years_experience: string | null
        }
        Insert: {
          created_at?: string
          details?: Json
          email: string
          files?: Json
          full_name: string
          id?: string
          location: string
          notes?: string | null
          phone: string
          registration_number: string
          status?: string
          years_experience?: string | null
        }
        Update: {
          created_at?: string
          details?: Json
          email?: string
          files?: Json
          full_name?: string
          id?: string
          location?: string
          notes?: string | null
          phone?: string
          registration_number?: string
          status?: string
          years_experience?: string | null
        }
        Relationships: []
      }
      physiotherapist_applicants: {
        Row: {
          created_at: string
          details: Json
          email: string
          files: Json
          full_name: string
          id: string
          location: string
          notes: string | null
          phone: string
          registration_number: string
          status: string
          years_experience: string | null
        }
        Insert: {
          created_at?: string
          details?: Json
          email: string
          files?: Json
          full_name: string
          id?: string
          location: string
          notes?: string | null
          phone: string
          registration_number: string
          status?: string
          years_experience?: string | null
        }
        Update: {
          created_at?: string
          details?: Json
          email?: string
          files?: Json
          full_name?: string
          id?: string
          location?: string
          notes?: string | null
          phone?: string
          registration_number?: string
          status?: string
          years_experience?: string | null
        }
        Relationships: []
      }
      referrals: {
        Row: {
          contact: string
          created_at: string
          details: Json
          friend_contact: string
          friend_name: string
          full_name: string
          id: string
          notes: string | null
          status: string
        }
        Insert: {
          contact: string
          created_at?: string
          details?: Json
          friend_contact: string
          friend_name: string
          full_name: string
          id?: string
          notes?: string | null
          status?: string
        }
        Update: {
          contact?: string
          created_at?: string
          details?: Json
          friend_contact?: string
          friend_name?: string
          full_name?: string
          id?: string
          notes?: string | null
          status?: string
        }
        Relationships: []
      }
      services: {
        Row: {
          category: string
          created_at: string
          description: string
          display_order: number
          id: string
          name: string
          status: string
        }
        Insert: {
          category: string
          created_at?: string
          description: string
          display_order?: number
          id: string
          name: string
          status?: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string
          display_order?: number
          id?: string
          name?: string
          status?: string
        }
        Relationships: []
      }
      testimonials: {
        Row: {
          created_at: string
          detail: string | null
          id: string
          name: string
          published: boolean
          quote: string
        }
        Insert: {
          created_at?: string
          detail?: string | null
          id?: string
          name: string
          published?: boolean
          quote: string
        }
        Update: {
          created_at?: string
          detail?: string | null
          id?: string
          name?: string
          published?: boolean
          quote?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      waitlist: {
        Row: {
          created_at: string
          email: string
          id: string
          notes: string | null
          parent_city: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          notes?: string | null
          parent_city: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          notes?: string | null
          parent_city?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin"],
    },
  },
} as const
